"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Activity, AlertCircle, ChevronDown, ChevronLeft, Clock, FileSpreadsheet, Upload } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function NewCampaignPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [isProcessing, setIsProcessing] = useState(false)

  // Form state
  const [campaignName, setCampaignName] = useState("")
  const [maxDistance, setMaxDistance] = useState([2000])
  const [flowId, setFlowId] = useState("")
  const [whatsappConfigId, setWhatsappConfigId] = useState("")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedFile(file)
    }
  }

  const handleCreateCampaign = async () => {
    setIsProcessing(true)

    // Simulate processing
    setTimeout(() => {
      setIsProcessing(false)
      router.push("/campanas/1")
    }, 3000)
  }

  const steps = [
    { number: 1, title: "Configuración" },
    { number: 2, title: "Cargar Archivo" },
    { number: 3, title: "Confirmar" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ChevronLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600">
                <Activity className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-foreground">Nueva Campaña de Recupero</h1>
                <p className="text-sm text-muted-foreground">Configurá y procesá tu campaña DTV</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8 max-w-4xl">
        {/* Stepper */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center flex-1">
                <div className="flex flex-col items-center">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-full border-2 font-semibold transition-colors ${
                      currentStep >= step.number
                        ? "border-blue-600 bg-blue-600 text-white"
                        : "border-border bg-background text-muted-foreground"
                    }`}
                  >
                    {step.number}
                  </div>
                  <span
                    className={`mt-2 text-sm font-medium ${
                      currentStep >= step.number ? "text-foreground" : "text-muted-foreground"
                    }`}
                  >
                    {step.title}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`h-0.5 flex-1 mx-4 transition-colors ${
                      currentStep > step.number ? "bg-blue-600" : "bg-border"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Step 1: Configuration */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configuración de Campaña</CardTitle>
                <CardDescription>Definí los parámetros básicos de tu campaña de recupero</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="campaign-name">Nombre de Campaña</Label>
                  <Input
                    id="campaign-name"
                    placeholder="Recupero DTV - Enero 2025"
                    value={campaignName}
                    onChange={(e) => setCampaignName(e.target.value)}
                  />
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Distancia Máxima a Punto Pickit</Label>
                    <div className="pt-2">
                      <Slider
                        value={maxDistance}
                        onValueChange={setMaxDistance}
                        min={500}
                        max={5000}
                        step={100}
                        className="w-full"
                      />
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">500m</span>
                      <Badge variant="secondary" className="font-mono">
                        {maxDistance[0]}m
                      </Badge>
                      <span className="text-muted-foreground">5000m</span>
                    </div>
                    <p className="text-sm text-muted-foreground">Clientes dentro de esta distancia serán contactados</p>
                  </div>
                </div>

                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Horario de envío automático:</strong> 12:00 - 15:00 (Argentina)
                  </AlertDescription>
                </Alert>

                <Collapsible>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between">
                      <span>Configuración Avanzada (Opcional)</span>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="flow-id">Flow ID de Kapso</Label>
                      <Input
                        id="flow-id"
                        placeholder="Dejar vacío para usar valor por defecto"
                        value={flowId}
                        onChange={(e) => setFlowId(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="whatsapp-config">WhatsApp Config ID</Label>
                      <Input
                        id="whatsapp-config"
                        placeholder="Dejar vacío para usar valor por defecto"
                        value={whatsappConfigId}
                        onChange={(e) => setWhatsappConfigId(e.target.value)}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Si no se completa, se usarán los valores por defecto del sistema
                    </p>
                  </CollapsibleContent>
                </Collapsible>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button
                onClick={() => setCurrentStep(2)}
                disabled={!campaignName}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Siguiente
              </Button>
            </div>
          </div>
        )}

        {/* Step 2: Upload File */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Cargar Archivo DTV</CardTitle>
                <CardDescription>Subí el archivo Excel con los datos de clientes a contactar</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {!selectedFile ? (
                  <div className="border-2 border-dashed border-border rounded-lg p-12 text-center hover:border-blue-600 transition-colors cursor-pointer">
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-foreground font-medium mb-2">
                        Arrastrá el archivo Excel de DTV o hacé click para seleccionar
                      </p>
                      <p className="text-sm text-muted-foreground">Solo archivos .xlsx o .xls (máx. 50MB)</p>
                      <input
                        id="file-upload"
                        type="file"
                        accept=".xlsx,.xls"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                    </label>
                  </div>
                ) : (
                  <div className="border border-border rounded-lg p-6">
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-500/10">
                        <FileSpreadsheet className="h-6 w-6 text-green-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{selectedFile.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                      <Button variant="outline" onClick={() => setSelectedFile(null)}>
                        Cambiar archivo
                      </Button>
                    </div>
                  </div>
                )}

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    El archivo debe incluir: <strong>teléfono, nombre, ubicación (lat/lon), nro cliente</strong>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setCurrentStep(1)}>
                Volver
              </Button>
              <Button
                onClick={() => setCurrentStep(3)}
                disabled={!selectedFile}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Siguiente
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Confirm */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Confirmar y Procesar</CardTitle>
                <CardDescription>Revisá la configuración antes de crear la campaña</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Nombre de campaña:</span>
                    <span className="font-medium text-foreground">{campaignName}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Distancia máxima:</span>
                    <span className="font-medium text-foreground">{maxDistance[0]}m</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Archivo seleccionado:</span>
                    <span className="font-medium text-foreground">{selectedFile?.name}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Horario de envío:</span>
                    <span className="font-medium text-foreground">12:00 - 15:00 (Argentina)</span>
                  </div>
                  {flowId && (
                    <div className="flex justify-between py-2 border-b border-border">
                      <span className="text-muted-foreground">Flow ID:</span>
                      <span className="font-medium text-foreground font-mono text-sm">{flowId}</span>
                    </div>
                  )}
                </div>

                <Alert className="bg-yellow-500/10 border-yellow-500/20">
                  <AlertCircle className="h-4 w-4 text-yellow-600" />
                  <AlertDescription className="text-yellow-800">
                    El procesamiento puede tomar unos minutos dependiendo del tamaño del archivo
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setCurrentStep(2)}>
                Volver
              </Button>
              <Button onClick={handleCreateCampaign} disabled={isProcessing} className="bg-blue-600 hover:bg-blue-700">
                {isProcessing ? "Procesando..." : "Crear Campaña y Procesar"}
              </Button>
            </div>
          </div>
        )}
      </main>

      {/* Processing Overlay */}
      {isProcessing && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50">
          <Card className="w-96">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="h-12 w-12 animate-spin rounded-full border-4 border-border border-t-blue-600" />
                <div>
                  <h3 className="font-semibold text-lg text-foreground mb-2">Procesando archivo Excel...</h3>
                  <p className="text-sm text-muted-foreground">Estamos cargando y procesando los datos de tu campaña</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
